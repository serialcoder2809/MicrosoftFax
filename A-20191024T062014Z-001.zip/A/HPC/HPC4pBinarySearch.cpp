#include<iostream>
#include<cstdlib>
#include<mpi.h>
using namespace std;

void parallel_binary_search(int a[], int start, int end,int key, int n, int rank)
{

	int mid;
	while(start <= end)
	{
		mid = (start + end)/2;
		if(a[mid] == key)
		{
			cout<<"Element found by processor "<<rank<<"\n";
			break;
		}
		else if(key>a[mid])
			start = mid + 1;
		else
			end = mid - 1;
	}
}

int main(int argc, char **argv)
{
	
	int rank, size;
	int n = 100;
	int key  = 75;
	int *a = new int[n];
	for(int i=0;i<n;i++)
		a[i] = i+1;

	MPI_Init(&argc, &argv);

	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	int blocks = 2;
	int block_size = n/2;
	cout<<"processor ->"<<rank<<"\n";
	cout<<"size->"<<size<<"\n";


	if(rank==0)
	{
		double start  = MPI_Wtime();
		parallel_binary_search(a, rank*block_size,(rank+1)*block_size-1,key, n, rank );
		double end  = MPI_Wtime();
		cout<<"Time taken by processor "<<rank<<"is "<<(end-start)*1000<<"\n";
	}
	else if(rank==1)
	{
		double start  = MPI_Wtime();
		parallel_binary_search(a, rank*block_size,(rank+1)*block_size-1,key, n, rank );
		double end  = MPI_Wtime();
		cout<<"Time taken by processor "<<rank<<"is "<<(end-start)*1000<<"\n";
	}
	else if(rank==2)
	{
		double start  = MPI_Wtime();
		parallel_binary_search(a, rank*block_size,(rank+1)*block_size-1,key, n, rank );
		double end  = MPI_Wtime();
		cout<<"Time taken by processor "<<rank<<"is "<<(end-start)*1000<<"\n";
	}

	MPI_Finalize();

	return 0;
}