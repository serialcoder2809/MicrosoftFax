def separate_by_class(dataset):
  separated = dict()
  for i in range(len(dataset)):
    row = dataset[i]
    class_value = row[-1]
    if class_value not in separated:
      separated[class_value] = list()
    separated[class_value].append(row)
    
  return separated



from math import sqrt,exp,pi

def mean(numbers):
  return sum(numbers)/float(len(numbers))
  
  
  
def std_dev(numbers):
  sum = 0
  avg = mean(numbers)
  for i in range(len(numbers)):
    xi = numbers[i]
    sum += (xi-avg)**2
    
  variance = sum/float(len(numbers))
  
  return sqrt(variance)
  

def summarize(dataset):
  summary = []
  for column in zip(*dataset):
    temp = [mean(column),std_dev(column),len(column)]
    summary.append(temp)
    
  del(summary[-1])
  return summary
  

def summarize_by_class(dataset):
  summary = dict()
  separated = separate_by_class(dataset)
  for key,value in separated.items():
    summary[key] = summarize(separated[key])
    
  return summary
  

def gaussian_probability(x,mean,stddev):
  e = exp( ( - (x-mean)**2 ) / ( 2*(stddev**2) ) )
  f = 1/(sqrt(2*pi)*stddev)

  return e*f

#gaussian_probability(1.0,1.0,1.0)


def calculate_class_probabilities(summaries, row):
  total_rows = 10
  probabilities = {}
  probabilities[0] = summaries[0][0][2]/float(total_rows)
  probabilities[1] = summaries[1][0][2]/float(total_rows)
  
  print(summaries)
  for key,value in summaries.items():
    for i in range(len(value)):
      probabilities[key] *= gaussian_probability(row[i],value[i][0],value[i][1])
      
  return probabilities

dataset = [[3.393533211,2.331273381,0],
    [3.110073483,1.781539638,0],
    [1.343808831,3.368360954,0],
    [3.582294042,4.67917911,0],
    [2.280362439,2.866990263,0],
    [7.423436942,4.696522875,1],
    [5.745051997,3.533989803,1],
           \
    [9.172168622,2.511101045,1],
    [7.792783481,3.424088941,1],
    [7.939820817,0.791637231,1]]

summaries = summarize_by_class(dataset)
probabilities = calculate_class_probabilities(summaries, dataset[2])
print(round(probabilities[1],10))
#summarize_by_class(dataset)
#std_dev([10, 12, 23, 23, 16, 23, 21, 16])