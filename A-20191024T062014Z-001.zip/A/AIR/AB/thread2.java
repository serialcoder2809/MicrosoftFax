// package pruning;

public class thread2 extends Thread{
    display d;
    int[] scores;
    int height;

    int MAX = 1000;
    int MIN = -1000;

    thread2(int[] scores,int height)
    {
        this.scores=scores;
        this.height=height;

        d = new display();
        d.add_elements(scores,height);
    }
    public void run()
    {
        try {
            int result =  minMax(0,0,true,this.scores,height,MIN,MAX);
            d.setRoot(result);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }



    public int minMax(int depth,int nodeNo,boolean isMax,int scores[],int h,int alpha,int beta) throws InterruptedException {
        if(depth == h)
        {
            System.out.println("currently evaluating node = "+scores[nodeNo]);
            d.setColor(nodeNo);
            this.sleep(2000);
            return scores[nodeNo];

        }

        else if(isMax)
        {
            int best = MIN;
            for(int i=0;i<2;i++)
            {
                int val = minMax(depth+1,nodeNo*2+i,false,scores,h,alpha,beta);
                best = Math.max(val,best);
                alpha = Math.max(alpha,best);

                if(beta<=alpha)
                    break;
            }
            d.setText(best,depth,nodeNo*2,nodeNo*2+1);
            this.sleep(2000);
            return best;
        }

        else
        {
            int best = MAX;
            for(int i=0;i<2;i++)
            {
                int val = minMax(depth+1,nodeNo*2+i,true,scores,h,alpha,beta);
                best = Math.min(best,val);
                beta = Math.min(beta,best);

                if(beta<=alpha)
                    break;
            }

            d.setText(best,depth,nodeNo*2,nodeNo*2+1);
            this.sleep(2000);
            return best;
        }



    }

}
